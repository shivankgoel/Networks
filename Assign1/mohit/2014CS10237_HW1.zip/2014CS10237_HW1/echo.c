#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>   //printf
#include <string.h> //memset
#include <stdlib.h> //exit(0);
#include <arpa/inet.h>
#include <ctype.h>

#define P 1000
#define PORT 8811   //The port on which to send data

int main(int argc, char *argv[])
{
	
    int s = socket(AF_INET,SOCK_DGRAM,0);//creating the socket for connection

	if(s < 0)
	{
		perror("cannot create socket");
	}
	else
	{
		printf("%s\n","Socket created");
	}

	
	struct sockaddr_in myaddr;
	unsigned int slen = sizeof(myaddr);

	memset((char *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	myaddr.sin_port = htons(PORT); 

	int b = bind(s, (struct sockaddr *)&myaddr, sizeof(myaddr)) ;  //for binding to the socket
	if(b < 0)
	{
		perror("bind failed");
	}
	else
	{
		printf("%s\n","Binding done");	
	}

	
	int rc ,rcc ,c;
	long long int tc;
	int recvl;
	long long int arr[(P/8) + 1];

    while(1)
    {
	printf("Waiting for data...\n");
	fflush(stdout);

        if ((recvl = recvfrom(s, arr, sizeof(arr), 0, (struct sockaddr *) &myaddr, &slen)) == -1)
        {												//receiving data from the client	
            perror("packet receiving error");
        }
	
	printf("Received packet from %s:%d\n", inet_ntoa(myaddr.sin_addr), ntohs(myaddr.sin_port));      
	
	arr[0] = arr[0] - 1;    //reducing the value of RC by one as received from the client

	printf("Data: %lld\n" , arr[0]); // print the data received  	

        if (sendto(s, arr, sizeof(arr) , 0 , (struct sockaddr *) &myaddr, slen) == -1)			//sending packet back to the client by reducing its value by 1 	
        {												//if error occurs it prints packet sending error else prints Sent			
            perror("packet sending error");
        }	
	else
	{
		printf("%s\n","Sent");
	}
	        
	 
    }
 
    close(s);
    return 0;
}
