#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <stdio.h>   //printf
#include <string.h> //memset
#include <stdlib.h> //exit(0);
#include <arpa/inet.h>
#include <ctype.h>


#define SERVER "10.208.20.170" //IP of other PC
#define PORT 8811   //The port on which to send data

long long int gts() 
{
	struct timeval timer_usec; 
	long long int timestamp_usec; /* timestamp in microsecond */
	if (!gettimeofday(&timer_usec, NULL)) {
    timestamp_usec = ((long long int) timer_usec.tv_sec) * 1000000ll + 
                        (long long int) timer_usec.tv_usec;
  }
  else {
    timestamp_usec = -1;
  }
  return timestamp_usec;
}
void help()
{
	printf("%s\n","This is the client file which is responsible for sending the data initially to the server and reduces value of RC each time we receive the value till RC = 0" );
}

int main(int argc, char *argv[])
{
	if(argc < 2 && strcmp(argv[1],"-h") == 0)
	{
		help();
		return 0;
	}
	int P ;
	char* p[20];
	*p = argv[1];
	P = atoi(*p);
	
	int T ;
	char* t[20];
	*t = argv[2];
	T = atoi(*t);

	
	char* outt ;
	outt = argv[3];

	
	int s = socket(AF_INET,SOCK_DGRAM,0); // creating the socket for connection
	if(s < 0)
	{
		perror("cannot create socket");
	}
	else
	{
		printf("%s\n","Socket created");
	}
	
	struct sockaddr_in myaddr;
	unsigned int slen = sizeof(struct sockaddr_in);

	memset((char *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons(PORT); // port over here
	if (inet_aton(SERVER , &myaddr.sin_addr) == 0)            // Create datagram with server IP and port.
	{
	    fprintf(stderr, "inet_aton() failed\n");
	    exit(1);
	}
	
	//int T = 8000;
	int rc ,rcc;
	long long int t ,tc;
	int i,c;
	//int P;
	long long int avg = 0;
	
	FILE *f = fopen(outt, "w");

		if (f == NULL)

		{						//open file to take the input	

		    printf("Error opening file!\n");

		    exit(1);

		}
//for( P = 100;P <=1000 ; P = P+100)
//{
	long long int arr[(P/8)+1];       //array to be sent size of long long int = 8 bytes , so for given P , size of array taken is (P/8)+1
	avg = 0;
	for(i = 0;i<50;i++)
	{
		arr[0] = T;		//arr[0] stores the value of T
		arr[1] = gts();		//arr[1] stores the value of timestamp
		arr[2] = i;		//i stores the sequence number
		
		while(arr[0] > 0)
		{
			
			if (sendto(s, arr, sizeof(arr), 0 , (const struct sockaddr *) &myaddr, slen) == -1)
			{
			    perror("packet sending error");			//sending packet to the echo file and if it fails to do so it prints error					
			}
			
			//clear the buffer by filling null, it might have previously received data
			memset(arr,'\0', P);
			//try to receive some data, this is a blocking call
			
			struct timeval tv;
				tv.tv_sec = 0;
				tv.tv_usec = 100000;
													//timeout settings
				if (setsockopt(s, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) < 0) 
				{
				    break;
				}

			if (recvfrom(s, arr,sizeof(arr) , 0, (struct sockaddr *) &myaddr, &slen) == -1)
			{
			    perror("packet receiving error");						//receiving packets from echo server file
			}
			arr[0] = arr[0] - 1;  //decrease the value of rc by one and check condition in while loop to send it back
			
		}

		long long int rtt = gts() - arr[1] ; 		 //getting RTT value by subtracting value of initial timestamp from current time
		avg = avg + rtt ;			//for finding average RTT of 50 packets
		
		if(arr[0] <= 0)
		{
			fprintf(f, "%d   %lld",P, rtt);		//printing value of P and corresponding cumulative RTT in file
			fprintf(f, "\n");	
		}
		else
		{
			const char *text = "Packet lost";	//if a packet was lost print packet lost in output file
			fprintf(f, "%s\n", text);
		}
		
		printf("Sequence number  %d\n",arr[2]);
		
	}
	printf("Average RTT is : %lld\n",avg/50); //print average RTT for each P
	
//}
	fclose(f);
	
	return 0;
}





























